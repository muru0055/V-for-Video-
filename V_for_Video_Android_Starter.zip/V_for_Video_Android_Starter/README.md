# V for Video — Android starter project

English-only Kotlin/Jetpack Compose starter for an offline video and audio player, with a black/purple dashboard and local file pickers.

## Current scope
- Choose and play one local video or audio file
- Basic play/pause/restart controls
- Dark premium dashboard
- Volume slider UI

## Important limitations
This is source code, not a compiled APK or a finished Play Store release. The current player volume is capped at 100%; the 200–300% boost is only a UI target until real audio processing is implemented. Automatic library scanning, persistent playlists, background playback service, equalizer, subtitles, PiP, and full device QA are not included yet.

Build using Android Studio or a cloud Android build environment with Java 17 and Android SDK 35. For Play Store, create and test a signed release AAB, prepare store assets and a privacy policy, and comply with current Play Console requirements.
