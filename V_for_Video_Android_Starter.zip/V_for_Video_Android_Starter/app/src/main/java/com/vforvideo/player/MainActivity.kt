package com.vforvideo.player

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private val Bg = Color(0xFF09090F)
private val Panel = Color(0xFF171722)
private val Purple = Color(0xFF9B5CFF)
private val Muted = Color(0xFFB9B8C7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val player = ExoPlayer.Builder(this).build()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = Panel)) {
                PlayerDashboard(player)
            }
        }
    }
}

@Composable
private fun PlayerDashboard(player: ExoPlayer) {
    var title by remember { mutableStateOf("Nothing playing yet") }
    var isPlaying by remember { mutableStateOf(false) }
    var boost by remember { mutableFloatStateOf(1f) }
    var isVideo by remember { mutableStateOf(false) }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) { title = uri.lastPathSegment?.substringAfterLast('/') ?: "Selected video"; isVideo = true; player.setMediaItem(MediaItem.fromUri(uri)); player.prepare(); player.play(); isPlaying = true }
    }
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) { title = uri.lastPathSegment?.substringAfterLast('/') ?: "Selected audio"; isVideo = false; player.setMediaItem(MediaItem.fromUri(uri)); player.prepare(); player.play(); isPlaying = true }
    }
    DisposableEffect(player) { onDispose { player.release() } }

    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).background(Purple, RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) { Text("V", fontSize = 29.sp, fontWeight = FontWeight.Black, color = Color.White) }
            Spacer(Modifier.width(12.dp))
            Column { Text("V for Video", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White); Text("OFFLINE MEDIA PLAYER", fontSize = 10.sp, color = Muted, letterSpacing = 1.5.sp) }
        }
        Spacer(Modifier.height(26.dp))
        Text("Your media, your way.", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Play videos and music stored on your device.", color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ActionCard("Open Video", "Choose a video file", { Icon(Icons.Default.Movie, null, tint = Purple) }, Modifier.weight(1f)) { videoPicker.launch(arrayOf("video/*")) }
            ActionCard("Open Music", "Choose an audio file", { Icon(Icons.Default.AudioFile, null, tint = Purple) }, Modifier.weight(1f)) { audioPicker.launch(arrayOf("audio/*")) }
        }
        Spacer(Modifier.height(20.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("NOW PLAYING", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                Spacer(Modifier.height(8.dp)); Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (isVideo) AndroidView(factory = { context -> PlayerView(context).apply { this.player = player } }, update = { it.player = player }, modifier = Modifier.fillMaxWidth().height(190.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { player.seekTo(0); player.play(); isPlaying = true }) { Icon(Icons.Default.RestartAlt, "Restart", tint = Muted) }
                    IconButton(onClick = { if (player.isPlaying) { player.pause(); isPlaying = false } else { player.play(); isPlaying = true } }, modifier = Modifier.size(58.dp).background(Purple, RoundedCornerShape(50))) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play or pause", tint = Color.White) }
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Volume Booster", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Text("${(boost * 100).toInt()}%", color = Purple, fontWeight = FontWeight.Bold) }
                Text("Boost control preview", color = Muted, fontSize = 12.sp)
                Slider(value = boost, onValueChange = { boost = it; player.volume = it.coerceAtMost(1f) }, valueRange = 0f..3f, steps = 29)
                Row(verticalAlignment = Alignment.CenterVertically) { Text("100%", color = Muted, fontSize = 12.sp); Spacer(Modifier.weight(1f)); Text("300% target", color = Muted, fontSize = 12.sp); TextButton(onClick = { boost = 1f; player.volume = 1f }) { Text("Reset") } }
                Text("Starter limitation: actual player volume is capped at 100%. Extra loudness requires additional audio processing and may distort sound.", color = Muted, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(20.dp)); Text("LIBRARY", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp); Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Videos", "Songs", "Folders", "Playlists").forEach { label -> Surface(color = Color(0xFF211D2D), shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1f)) { Text(label, Modifier.padding(vertical = 12.dp, horizontal = 5.dp), color = Color.White, fontSize = 11.sp, maxLines = 1) } } }
        Spacer(Modifier.height(18.dp)); Text("V for Video • English only", color = Color(0xFF777586), fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, icon: @Composable () -> Unit, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp), modifier = modifier) {
        Column(Modifier.padding(15.dp)) { icon(); Spacer(Modifier.height(15.dp)); Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp); Spacer(Modifier.height(4.dp)); Text(subtitle, color = Muted, fontSize = 11.sp) }
    }
}
